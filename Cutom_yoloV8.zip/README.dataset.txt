# Obj_detect_YOLO_V7 > 2023-02-15 6:25pm
https://universe.roboflow.com/object-detection/obj_detect_yolo_v7

Provided by a Roboflow user
License: Public Domain

